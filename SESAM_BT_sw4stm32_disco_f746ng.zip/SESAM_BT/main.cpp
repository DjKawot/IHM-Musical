#include "mbed.h"
#include "LCD_DISCO_F746NG.h"



LCD_DISCO_F746NG lcd;


void Init();
void LectureSerie();
void EnvoiSerie();
void onMsgReceived();


Serial Bluetooth(D1, D0);

PwmOut led(A0);


char acquisition = 0;
volatile bool msgAvailable = false;

int main()
{  
    lcd.DisplayStringAt(0, LINE(1), (uint8_t *)"Bt Test", CENTER_MODE);
    wait(1);
  
    
      lcd.Clear(LCD_COLOR_BLUE);
      lcd.SetBackColor(LCD_COLOR_BLUE);
      lcd.SetTextColor(LCD_COLOR_WHITE);
      wait(0.3);
      Init();
      char msg[8] = { 0 };
      int value = 8;

    while(1) 
    {
        /*if(Bluetooth.readable()) 
        {                    
            Bluetooth.putc('A');
            *msg = *(Bluetooth.gets(msg,value));
        
            lcd.DisplayStringAt(0, LINE(5), (uint8_t *)msg, CENTER_MODE);
        }*/    
        led = 0.5;
        /*
        led = led + 0.01;
        wait(0.2);
        if(led == 1.0) {
            led = 0;
        
        }*/
    }  
    
}

void Init()
{
    Bluetooth.baud(115200);   
}