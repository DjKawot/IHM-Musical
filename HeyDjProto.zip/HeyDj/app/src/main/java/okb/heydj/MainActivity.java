package okb.heydj;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.ParcelUuid;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;


public class MainActivity extends AppCompatActivity {

    BluetoothAdapter bluetoothAdapter;
    TextView capteur;
    Spinner spinner;

    List<String> list = new ArrayList<String>();

    //Contient tous les appreils detectés
    BluetoothDevice[] ListeAppareil = new BluetoothDevice[20];

    //Recupert l'appreil choisi pour se connecter
    BluetoothDevice AppareilSelect;

    //Bluetooth echange
    BluetoothSocket socket;

    OutputStream outputStream;
    InputStream mmInputStream;

    Thread transmet;
    byte[] data = new byte[1];


    private AtomicBoolean ThreadAlive = new AtomicBoolean();


    String message;


    Button do_1;
    Button re_1;
    Button mi_1;
    Button fa_1;
    Button sol_1;
    Button la_1;
    Button si_1;
    Button do_2;

    int cpt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        do_1 = (Button)findViewById(R.id.btn_Do_1);
        re_1 = (Button)findViewById(R.id.btn_Re_1);
        mi_1 = (Button)findViewById(R.id.btn_Mi_1);
        fa_1 = (Button)findViewById(R.id.btn_Fa_1);
        sol_1 = (Button)findViewById(R.id.btn_Sol_1);
        la_1 = (Button)findViewById(R.id.btn_La_1);
        si_1 = (Button)findViewById(R.id.btn_Si_1);
        do_2 = (Button)findViewById(R.id.btn_Do_2);

        final Button btn_Connect = (Button) findViewById(R.id.btnConnexion);
        capteur = (TextView) findViewById(R.id.txtCapteur);
        spinner = (Spinner) findViewById(R.id.ListeAppareilBluetooth);


        //----------------------------------------------------------------------------------------*/




        btn_Connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                 if(btn_Connect.getText().equals("CONNEXION") == true)
                {
                    OpenConnection();
                    btn_Connect.setText("DECONNEXION");
                }
                else if (btn_Connect.getText().equals("DECONNEXION") == true)
                {
                    Deconnection();
                    btn_Connect.setText("CONNEXION");
                }//*/
            }
        });


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                AppareilSelect = bluetoothAdapter.getRemoteDevice(ListeAppareil[position].toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });
        ActivationBluetooth();


        //----------------------------------------------------------------------------------------*/

        do_1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                data[0]=(byte)0x42;cpt=0;
                return false;
            }
        });

        re_1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                data[0]=(byte)0x43;cpt=0;
                return false;
            }
        });

        mi_1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                data[0]=(byte)0x44;cpt=0;
                return false;
            }
        });

        fa_1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                data[0]=(byte)0x45;cpt=0;
                return false;
            }
        });

        sol_1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                data[0]=(byte)0x46;cpt=0;
                return false;
            }
        });

        la_1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                data[0]=(byte)0x47;cpt=0;
                return false;
            }
        });

        si_1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                data[0]=(byte)0x47;cpt=0;
                return false;



            }
        });

        do_2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                data[0]=(byte)0x48;cpt=0;
                return false;
            }
        });




        //----------------------------------------------------------------------------------------*/
    }



    private final static int REQUEST_CODE_ENABLE_BLUETOOTH = 0;

    void ActivationBluetooth()
    {


        int result_intent = 0;
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        //----------------------------------------------------------------------------------------*/
        // vérifie si l'appareil possède ou non un module Bluetooth
        /*
        if (bluetoothAdapter == null) {
            Toast.makeText(MainActivity.this, "L'appareil ne possède pas de bluetooth",
                    Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(MainActivity.this, "Possède Bluetooth",
                    Toast.LENGTH_SHORT).show();
        }
        //----------------------------------------------------------------------------------------*/


        // propose à l'utilisateur d'activé le Bluetooth si il est désactivé
        /*
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBlueTooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBlueTooth, REQUEST_CODE_ENABLE_BLUETOOTH);
        }//*/

        // Permet d'activé le Bluetooth sans demander l'avis de l'utilisateur

        if (!bluetoothAdapter.isEnabled()) {
            bluetoothAdapter.enable();
        }


        //----------------------------------------------------------------------------------------*/
        //Recupere la liste des appareils visibles

        int i = 0;
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if(pairedDevices.size() > 0)
        {
            for(BluetoothDevice device : pairedDevices)
            {
                list.add(device.getName());
                ListeAppareil[i] = device;
                i++;
            }
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);

        AppareilSelect = ListeAppareil[0];
    }


    //----------------------------------------------------------------------------------------*/
    // Déconnecte l'appareil
    void Deconnection()
    {
        capteur.setText("deco");

        Toast.makeText(MainActivity.this, "Deconnection",
                Toast.LENGTH_SHORT).show();

        try {
            socket.close();
        }catch (IOException e){}


    }


    //----------------------------------------------------------------------------------------*/
    // Tente d'établir un connection
    void OpenConnection()
    {
        data[0]=(byte)0x01;
        ParcelUuid[] uuid = AppareilSelect.getUuids();
        Log.e("ID", AppareilSelect.toString());
        try
        {
            socket = AppareilSelect.createRfcommSocketToServiceRecord(uuid[0].getUuid());

            socket.connect();

            outputStream = socket.getOutputStream();
            mmInputStream = socket.getInputStream();

            capteur.setText("Connection etablie");

            Toast.makeText(MainActivity.this, "Connection etablie",
                    Toast.LENGTH_SHORT).show();

        }
        catch (IOException e)
        {
            capteur.setText("Connection erreur");
            e.printStackTrace();

            Toast.makeText(MainActivity.this, "Connection erreur",
                    Toast.LENGTH_SHORT).show();
        }

        //initialise le Thread
        EmetData();

        //Lance le thread
        ThreadAlive.set(true);
    }



    //----------------------------------------------------------------------------------------*/



    //emmet les données
    void EmetData()
    {
        transmet = new Thread(new Runnable()
        {

            public void run()
            {
                while (true)
                {

                    try {
                        if ( data[0] != (byte)0x00){
                        outputStream.write(data);
                        cpt++;}

                        if (cpt > 1)
                        {
                            data[0]=(byte)0x00;
                        }

                    } catch (IOException e) {}
                }
            }
        });
        transmet.start();
    }



    protected void onDestroy()
    {
        super.onDestroy();

        ThreadAlive.set(false);
        // trasmet.interrupt();
        try
        {
            transmet.join(100);
        } catch (InterruptedException e)
        {
            e.printStackTrace();
        }
    }
}
